import os
from cognition import Cognition

def main():
    # Provide a dummy key if not set in the environment
    api_key = os.environ.get("COGNITION_API_KEY", "test_key_123")
    
    # Initialize the synchronous client
    client = Cognition(api_key=api_key)
    
    print("--- Testing /ask (Non-streaming) ---")
    try:
        response = client.ask(
            prompt="Hello, world!",
            model="llama-3.1-8b-instant"
        )
        print("Response:", response)
    except Exception as e:
        print("API call failed (expected if dummy key is used):", e)
        
    print("\n--- Testing /ask (Streaming) ---")
    try:
        stream = client.ask(
            prompt="Tell me a joke",
            stream=True
        )
        for chunk in stream:
            print(chunk, end="")
        print()
    except Exception as e:
        print("API call failed (expected if dummy key is used):", e)
        
    print("\n--- Testing /tts ---")
    try:
        audio_bytes = client.audio.speech.create(
            input="Welcome to Cognition AI.",
            encoding="binary"
        )
        print(f"Received {len(audio_bytes)} bytes of audio.")
    except Exception as e:
        print("API call failed (expected if dummy key is used):", e)

if __name__ == "__main__":
    main()
